#!venv-linux/bin/python3

from view import *

if __name__ == "__main__":
    launch()
