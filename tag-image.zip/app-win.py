#!venv-win\Scripts\python.exe

from view import *

if __name__ == "__main__":
    launch()
